package com.example.moca;

public class Api {
//        public static String api = "http://192.168.3.19/MOCA_AME/";
    public static String api = "http://10.0.2.2/MOCA_AME/";
//        public static String api = "http://172.23.17.88/MOCA_AME/";
    public static String getApi() {
        return api;
    }
}
