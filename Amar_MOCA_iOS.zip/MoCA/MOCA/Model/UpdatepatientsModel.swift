//
//  AddPatientModel.swift
//  MOCA
//
//  Created by SAIL on 20/10/23.
//

import Foundation

struct UpdatepatientsModel: Codable {
    var id, status, message: String?
}
