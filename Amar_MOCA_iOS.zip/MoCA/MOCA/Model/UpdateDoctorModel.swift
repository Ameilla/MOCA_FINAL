//
//  UpdateDoctorModel.swift
//  MOCA
//
//  Created by AMAR on 03/12/23.
//

import Foundation

struct UpdateDoctorModel: Codable {
    let id, status, message: String
}
